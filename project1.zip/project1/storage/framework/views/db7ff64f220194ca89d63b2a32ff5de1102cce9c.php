
<!-- Footer -->
<footer id="footer">
    <p class="copyright">&copy; Untitled. All rights reserved. Demo Images: <a href="https://unsplash.com">Unsplash</a>. Design: <a href="https://html5up.net">HTML5 UP</a>.</p>
</footer>
</div>
</div>

</div>

<!-- Scripts -->
<script src="<?php echo e(URL::asset('js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('js/skel.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('js/util.js')); ?>"></script>
<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
<script src="<?php echo e(URL::asset('js/main.js')); ?>"></script>